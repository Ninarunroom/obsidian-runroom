---
tipo: status-semanal
cliente: Esade
linea: SEO y Analítica
fecha: 2026-11-12
---
# Status semanal — Esade SEO y Analítica · 12/11/2026

> [!info] Cómo funciona
> Cada lunes sale un status nuevo en esta carpeta, con el texto listo para Slack al final. Compara con el status anterior: lo que no se ha movido en una semana aparece en ⏰.
> Pide al equipo que responda en el hilo antes del **martes a mediodía** con: qué cierra, **fecha de entrega** de lo que está en curso y bloqueos.

## Fer · SEO técnico

**⏰ Vencido o sin movimiento**
- **Schema**: devolver a Sergi los matices a su propuesta (redes en schema). Sergi lo envió el 07/10 y en el hilo solo ha respondido Natzir. → [📧 Coses Schema](https://mail.google.com/mail/?authuser=nina@runroom.com#all/thread-f:1878390725484215667)
- **Informe de marca en LLMs** (1.ª entrega): el roadmap lo situaba en oct–nov y no ha arrancado. → [[Estrategia 26-27 - seguimiento Esade SEO]]
- **Mapa competitivo ampliado**: acordado en la reunión de estrategia del 18/09; sin arrancar.
- **Excel del EMBA sin actualizar**: las 20 tareas del backlog siguen en "Pendiente", también la F0-01, que se entregó el 26/10. Última edición: Natzir, 05/11. → [Excel EMBA](https://drive.google.com/file/d/17wPCCI_OlSEpzuTz6EX7LARGX6vP9JEN/view)

**🔄 En curso (falta fecha de entrega)**
- **EMBA, recuperar las posiciones 4-10** (es un único trabajo: el backlog F0-F4 del Excel y la línea "Recuperar las consultas caídas de 4-10" del plan de acción). La ficha de queries perdidas (F0-01) se entregó el 26/10. Fer dijo el 26/10 que se ponía con la F0-02 (qué competidores ocupan ahora esas posiciones y con qué contenido) y desde entonces no hay novedades en el hilo; el 27/10 Sergi escribió "estem d'emergència". Sergi pidió el 01/10, en el mismo hilo, un inventario de "ja existeix / cal actualitzar / cal crear" antes de producir el contenido de F1-01, 02, 05, 06, 07 y 08. → [Basecamp: EMBA](https://basecamp.com/1771388/projects/19742261/messages/113264682)
- Full Time MBA: análisis de la ficha y del mercado indio (Sergi: "Activem tots els next steps", 29/10). → [Basecamp: Full Time MBA](https://basecamp.com/1771388/projects/19742261/messages/113563313)

**⬜ Por empezar**
- Grados: caída de impresiones de "student loans" de 100k a 0 (Sergi, 03/11). Parece más indexación que estacionalidad. → [📧 Dashboard Setembre](https://mail.google.com/mail/?authuser=nina@runroom.com#all/thread-f:1878407521139447114)
- EMBA: acciones SEO fuera de la web con Olga, a partir del 20/11.

**📅 Lo próximo en el roadmap**
- Auditoría técnica (dic 2026–ene 2027): rastreo por BU, renderizado, hreflang y canónicas. Coordinar con Natzir para no duplicar.

**✅ Cerrado**
- Fichas de keywords y metadatos de Relaciones Corporativas y Becas (09/11; ahora en validación por Esade).
- Capturas de KPIs de IA a 31/08 para Helen (05/11).

## Marta · Analítica

**🔄 En curso (falta fecha de entrega)**
- Tráfico bot de China: aplicar lo que aprobó Sergi el 10/11, con las notas de Natzir del 11/11. → [Basecamp: Xina](https://basecamp.com/1771388/projects/16901662/messages/113457396)

**⬜ Por empezar (nuevo)**
- Ajustes de consentimiento en GTM: los 5 puntos de Sergi (11/11). → [📧 Ajustos de consentiment](https://mail.google.com/mail/?authuser=nina@runroom.com#all/thread-f:1881572888713368359)
- Pico de sesiones del 10/11: ¿modelización de Consent Mode o cambio en GTM, sGTM u OneTrust? → [📧 pic de sessions](https://mail.google.com/mail/?authuser=nina@runroom.com#all/thread-f:1881574014061694620)

**✅ Cerrado**
- Respuesta a la auditoría de píxeles de Adsmurai (10/11).

**⚠️ Gestión**
- Horas de octubre: sus filas llevan la OC012692, que es la de Do Better.

## 🟧 Esperando a Esade (contexto para el equipo)
- URLs de CrazyEgg (desde 01/10) · Unibuddy y su Hotjar (01/10) · respuesta de OneTrust sobre el 'unknown' (07/10) · prompts de Sistrix / LLM Pulse (02/10) · validación de las fichas de RRCC y Becas (10/11) · acciones del plan EMBA de Esade, Web y Natzir (13 y 20/11) · píxeles: OK de Helen y Adsmurai (10/11).

## Horas
- Remanente tras el cierre de octubre: **29 h** (dato de Nina). Agencia en octubre: 37,5 h (Fer 29, Marta 7, Olga 1,5).

---

## Texto para Slack

> [!tip] Cómo escribirlo para Fer
> Cada punto, numerado y autoexplicativo: qué es (sin códigos internos), por qué importa y una pregunta concreta. Si dos cosas son el mismo trabajo, van en un solo punto.

```
*Esade SEO y Analítica · status 12/11* 📋
Os paso lo que tenemos abierto. Contestadme en el hilo con el número y una línea: hecho / fecha en que lo tendréis / qué os bloquea. ¡Gracias! 🙏

*Fer*
1. *EMBA – recuperar las posiciones 4-10*: en el hilo de Basecamp dijiste el 26/10 que te ponías con la F0-02 (ver qué competidores ocupan ahora esas posiciones y qué contenido tienen) y desde entonces no hay novedades. Sergi escribió el 27/10 que "estem d'emergència" con el EMBA. Además, el 01/10 pidió que, antes de escribir contenido nuevo para esas páginas, hiciéramos un inventario de "ya existe / hay que actualizar / hay que crear". ¿Para cuándo tienes las dos cosas?
→ Basecamp EMBA: https://basecamp.com/1771388/projects/19742261/messages/113264682
2. *Excel del EMBA*: Sergi y Natzir lo usan para seguir el plan, y todo sigue en "Pendiente", incluso la ficha de queries perdidas (F0-01) que entregaste el 26/10. ¿Puedes poner al día los estados (Done / WIP) y revisarlo cada semana?
→ Excel: https://drive.google.com/file/d/17wPCCI_OlSEpzuTz6EX7LARGX6vP9JEN/view
3. *Schema*: el 07/10 Sergi nos pasó su propuesta (poner las redes sociales en el schema). Natzir le contestó el 08/10, pero nosotros todavía no. ¿Le mandas tus comentarios esta semana?
→ Correo "Coses Schema (tot i que la IA potser no en fa cas)", 07/10
4. *Full Time MBA*: Sergi dio el ok el 29/10 a los siguientes pasos que propusiste (ficha del programa y mercado indio). ¿Qué fecha le damos?
→ Basecamp Full Time MBA: https://basecamp.com/1771388/projects/19742261/messages/113563313
5. *Grados – "student loans"*: Sergi ha visto en el dashboard que las impresiones han pasado de 100.000 a 0. Parece más un tema de indexación que de temporada. ¿Lo puedes mirar?
→ Correo "Dashboard Setembre", 03/11
6. *Roadmap del curso*: en oct–nov tocaba el primer informe de cómo aparece Esade en las IA (ChatGPT, Gemini…) y el mapa de competidores ampliado. ¿Cuándo los arrancamos? Y en diciembre empieza la auditoría técnica: coordínala con Natzir para no hacer lo mismo dos veces.
→ Propuesta de estrategia 26/27 (diapositiva Roadmap): https://drive.google.com/file/d/1j-An1mGzy7ovzZyK4LJBpnQYWWhuRwP7/view
Para que lo tengas en el radar: a partir del 20/11, acciones fuera de la web para el EMBA con Olga.

*Marta*
1. *Bots de China*: Sergi aprobó tu propuesta el 10/11 y Natzir añadió notas el 11/11. ¿Cuándo estará aplicado?
→ Basecamp Xina: https://basecamp.com/1771388/projects/16901662/messages/113457396 · correo "Pico de bots en GA4 el 4 de noviembre", 11/11
2. *Consentimiento en GTM*: el 11/11 Sergi pidió revisar 5 puntos (CrazyEgg, YouTube, Flowbox, cookies _gcl/sbjs y functionality_storage). ¿Qué fecha le damos?
→ Correo "www.esade.edu · Ajustos de consentiment de galetes a GTM", 11/11
3. *Pico de sesiones del 10/11*: ¿cambió algo ese día en GTM, en el sGTM o en OneTrust, o es la modelización de Consent Mode, como dice Natzir? Sergi espera respuesta.
→ Correo "Esade: pic de sessions el 10/11 – és la modelització de Consent Mode?", 11/11
4. *Horas de octubre*: tus horas llevan la OC de Do Better (OC012692). ¿Las cambias a la del fee?

*Esperando a Esade* (no tenéis que hacer nada): URLs de CrazyEgg · Unibuddy · respuesta de OneTrust · prompts de Sistrix · validación de las fichas de RRCC y Becas · acciones del plan EMBA de su lado.
*Horas*: nos quedan 29 h de remanente tras octubre.
```
