# Log — Barraquer

Registro cronológico de lo que se ha hecho en esta carpeta (ingests de fuentes nuevas, consultas importantes respondidas y guardadas, revisiones/lint). Cada entrada empieza con `## [AAAA-MM-DD] tipo | título breve` para poder buscarlas con `grep "^## \[" "Log - Barraquer.md"`.

## [2026-10-20] reorganización | Reestructuración de la carpeta siguiendo el patrón LLM Wiki (info, Pendientes, Reuniones Raw/Procesadas, Claude/Instrucciones, este log)

## [2025-12-11] reunion | Next steps barraquer — preparación interna negociación de fee
Reunión interna previa a la negociación anual con Cristian: amenaza de salida en 2027 si no baja el % de fee. Ver Reuniones/Raw y Procesadas.

## [2025-12-18] reunion | Barraquer dubai hubspot migration — formación HubSpot Dubai
Sesión de soporte/formación HubSpot para la delegación de Dubai (Mohamed Akram Hanini).

## [2025-12-19] reunion | Brief barraquer 2026 — estrategia medios + tensión servicio web
Brief de medios 2026 y segunda parte tensa sobre el servicio web (proactividad, modelo de cobro, propuesta sin IPC).

## [2026-01-16] reunion | Cierre anual 2025 + estrategia 2026
Balance 2025 (inversión +15%, CPL 21€) y arranque de estrategia 2026; "Instituto" aplazado a marzo.

## [2026-05-14] reunion | Status RR — taxonomía de campañas y atribución
Revisión ene-abr; se acuerda estandarizar nomenclatura de campañas de marca y persisten problemas de categorización de patologías en el CRM.

## [2026-06-22] reunion | Revisión presus — arranque formal de la expansión a Madrid
Se define el presupuesto y enfoque de la expansión a Madrid, financiada con reserva existente (26.500€).

## [2026-07-07] reunion | Status — producción audiovisual y landing de Madrid
Puesta en marcha operativa del lanzamiento de Madrid: vídeos, landing, tracking HubSpot.

## [2026-07-09] reunion | Status RR — resultados de junio y saldo
Los leads de pago superan por primera vez al tráfico orgánico; presupuesto de Madrid integrado en el documento general.

## [2026-07-21] reunion | Status — incidente de seguridad y ajustes de Madrid
Acceso no autorizado a Google Ads (asociado a Dubai); cierre de producción de Madrid; recordatorio de que el servicio en Madrid es 100% privado.

## [2026-09-02] reunion | Status — salida de Magalí Federico y transición de cuenta
Magalí deja el equipo; Araceli Iglesias asume mayor peso como interlocutora con Cristian.

## [2026-09-10] reunion | Status RR — primera reunión tras el traspaso, discrepancias de datos
Se decide volver a separar las campañas por patología; NPS 81; discrepancias de inversión ene-ago sin cuadrar.

## [2026-10-08] reunion | Status RR — buen rendimiento de septiembre, llamadas como conversión secundaria
CPL de septiembre en 21€ (mejor dato del año); llamadas telefónicas pasan a conversión secundaria.

## [2026-10-20] ingesta | Ingesta de 12 reuniones de Barraquer desde Drive (dic 2025 - oct 2026)
Se procesaron las 12 reuniones disponibles en el Drive compartido, se crearon Raw/Procesadas por reunión, se actualizó Barraquer.md (contactos, Madrid, Dubai, incidente de seguridad, calidad de datos), se añadieron 5 pendientes nuevos y se completó Claude/Instrucciones - Barraquer.md con tono, aprobaciones y contexto multi-mercado.
## [2026-11-02] ingest | Añadidas cards recurrentes Presupuesto (semanal) y Facturación (mensual, noviembre) — generadas automáticamente, no vía Basecamp/email (fallo del trigger matutino, ver diagnóstico).

## [2026-11-05] reorganización | Nueva estructura de knowledge base de performance
Fuentes/ (Reuniones, Basecamp, Documentos) separadas de Wiki/ (Reuniones procesadas, Acuerdos, Propuestas y decisiones, Cronología, Mercados, Canales, Documentos, Personas). Nuevas notas: 00 Onboarding, Alertas. Pendientes reorganizado en 🟦 Runroom / 🟧 Cliente con "Esperando desde". Ingesta de 112 hilos de Basecamp (Barraquer - SEM, desde 09/2025) + 12 reuniones + BarraquerKB (rama vault). Instrucciones ampliadas con el nuevo esquema y las reglas de alertas. Copia de seguridad previa: _copia-seguridad-2026-11-05.tar.gz.

## [2026-11-05] reorganización | Estructura simplificada
Lo de uso diario queda arriba (Barraquer, Onboarding, Pendientes con Status, Contexto/, Reuniones/). Lo de Claude va a Claude/ (Instrucciones, Log, Fuentes/, copia de seguridad). Se elimina Alertas (pasa a ser el Status de Pendientes). Las alertas pasan a ser de campañas y de negocio (pacing, picos, campañas paradas, umbral de fee), por email. Se añade el acuerdo de escalado de fee (diciembre 2025) y la carpeta de Drive del cliente.

## [2026-11-05] panel | Panel KAM y seguimiento
Nuevas notas: Panel KAM (estrategia, tareas, facturación, horas, alertas, umbral de fee), Contexto/Estrategia 2026 - seguimiento (37 acciones de la propuesta 2026 con su estado), Horas - Barraquer (registro semanal, 35 h Ari / 19 h Nina) y Contexto/Sistema de alertas de campaña (propuesta para Ari). Revisión de facturación: no cuadra (medios −1.241 €, fee facturado +231 € sobre consumido, Detalle_Mensual −1.464 € frente a Presupuesto_Anual).

## [2026-11-05] saldos | Nueva nota Saldos - Barraquer: registro de recargas + saldo estimado por cuenta; alerta si baja del 20 % de la última recarga o de 5 días laborables de gasto.

## [2026-11-05] panel | Panel KAM rehecho con Dataview (estilo del dashboard de Harbest Brain): estrategia como tareas, horas y saldos con campos; Clínica + Estética = saldo único de Google Ads. Plugin Dataview copiado a la bóveda Runroom.

## [2026-11-05] decisión | TikTok descartado para 2026 (confirmado por Nina): estrategia [-], tarea de recarga cancelada, añadido a Propuestas y decisiones.

## [2026-11-05] reorganización | Carpetas numeradas: 1. Conocer la cuenta (Onboarding = ficha + onboarding), 2. Acuerdos, 3. Reuniones (Raw / Procesadas), 4. Estado tareas, 5. Panel KAM, Claude/. Barraquer.md fusionada en el Onboarding (alias Barraquer). Copia de seguridad: Claude/_copia-seguridad-2026-11-05b.tar.gz.

## [2026-11-05] mejora | Tareas de reuniones enlazadas a su acta procesada; eliminada la carpeta vacía Claude/Fuentes/Basecamp (Basecamp se consulta en directo).

## [2026-11-05] reorganización | Onboarding reducido a una pantalla; el detalle pasa a 1. Conocer la cuenta/Ficha de cuenta - Barraquer.

## [2026-11-05] reorganización | Onboarding renombrado a 00 Onboarding (sale el primero); las 7 notas de mercados y canales se juntan en Mercados y canales - Barraquer.

## [2026-11-05] reorganización | Onboarding eliminado: la puerta de entrada es 1. Conocer la cuenta/00 Ficha de cliente. Estado tareas + Panel KAM juntos en 4. Seguimiento (00 Panel KAM primero). Quitada la regla de Madrid de Reglas clave (ya está en la ficha).

## [2026-11-05] paneles | Panel KAM sustituido por 4 paneles en 4. Seguimiento: Tareas, Horas, Saldos, Facturación y fee. Pendientes y Estrategia 2026 pasan a Claude/Datos (se marcan desde el panel de Tareas). Facturas 2026 como lista con casillas (ene-oct marcadas).

## [2026-11-05] decisión | Cronología se mantiene tal cual (una línea por mes). El KB se queda en la bóveda de Nina, sin repo compartido.

## [2026-11-05] paneles | Horas: registro mensual por perfil (Head/KAM/Performance/Otros) desde la captura de Nina, con el cambio de reparto de septiembre (horas_plan). Saldos: sin anillo de %, ahora días que quedan + proyección diaria. Facturación: mes a mes con gráfico de barras y tabla más compacta.

## [2026-11-05] automatización | Nueva tarea programada "Barraquer - Actas de reunión" (L-V 17:43): busca las notas de Gemini en Drive y las pasa a 3. Reuniones (Raw + Procesadas), con registro en Claude/Datos/Actas procesadas. La tarea diaria de Basecamp deja de procesar reuniones. Código Paprika añadido al panel de Horas (2026 BAR020061, 2027 BAR020066).

## [2026-11-06] actas | 5 actas nuevas + 3 complementos, 12 documentos movidos
Nuevas: 2026-02-12 Status mensual (manual), 2026-04-30 Informe y nuevo presupuesto, 2026-06-12 Status RR (lanzamiento Madrid), 2026-07-28 Landing Madrid - eventos GTM (de Ari), 2026-08-19 Status agosto. Complementos: Kick off 2026 (→ acta 19/12/2025), estrategia 2026 (→ acta 16/01), STATUS 2 SEPT (→ acta 02/09). 0 tareas nuevas (todas las reuniones tienen más de 30 días). Ingest en Cronología, Propuestas y decisiones, Mercados y canales y Personas. ⚠️ en revisión: leads de julio (529 vs 634) y presupuesto 2026 (308.807 € del acta del 12/02 vs 266.894 € de clínica). 12 notas de Gemini de Nina movidas a 00. Actas reunión (11/12/2025 → 08/10/2026).
